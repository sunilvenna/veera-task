import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators ,FormControl} from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import {Router} from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  //title = 'veera';
  registerForm: FormGroup;
  submitted = false;

  constructor(private router: Router,private formBuilder: FormBuilder) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
            'firstName': new FormControl('', Validators.required),
            'lastName': new FormControl('', Validators.required),
            'mobile': new FormControl('', Validators.required),
            'email': new FormControl('', Validators.required),
            'address': new FormControl('', Validators.required),
            'confirmpassword': new FormControl('', Validators.required),
            'password': new FormControl('', Validators.required)
         // 'email':   new FormControl(['',  Validators.compose([Validators.required,  Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')])]),
          //'password': new FormControl(['', [Validators.required, Validators.minLength(8)]]),
          //'mobile':  new FormControl(['', [Validators.required, Validators.pattern("[0-9]{0-10}")]]),
          //'address': new FormControl(['', [Validators.required, Validators.minLength(30)]]),
          //'confirmpassword': new FormControl(['', [Validators.required, Validators.minLength(8)]])
      });
  }

  get veera() { return this.registerForm.controls; }
  onLoad(){
    this.router.navigate(['/home']);
  }
  onSubmit() {
      this.submitted = true;
      if (this.registerForm.invalid) {
        //this.router.navigate(['/home']);
        return;
         // return this.veera;
        // alert('SUCCESS!! :-)')
         //this.router.navigateByUrl('/home');
      }
     alert('SUCCESS!! :-)')
      
  }
 

  
}
